Create database Employee_DBMS;
use Employee_DBMS;
CREATE TABLE Employee(
  Employee_Id int(6) primary key,
  First_Name VARCHAR(25),
  Last_Name VARCHAR(25),
  Hire_Date DATE,
  City VARCHAR(25),
  State VARCHAR(25)
);
  CREATE TABLE Department(
  Department_Id int primary key,
  Department_Name VARCHAR(30)
  );
CREATE TABLE AccountDetails(
  Account_Id int primary key,
  Bank_Name VARCHAR(50),
  Account_Number VARCHAR(50),
  Employee_Id int,
  FOREIGN KEY (Employee_Id) REFERENCES Employee(Employee_Id)
  );
CREATE TABLE Salary(
  Salary_Id int primary key,
  Gross_Salary int,
  Hourly_Pay int,
  State_Tax int,
  Federal_Tax int,
  Account_Id int,
  FOREIGN KEY (Account_Id) REFERENCES ACCOUNTDETAILS(Account_Id)
  );
CREATE TABLE Project(
  Project_Id int primary key,
  Project_Name VARCHAR(50),
  Project_Description VARCHAR(50)
  );
CREATE TABLE DepartmentProject(
  Department_Id int,
  Project_Id int,
  PRIMARY KEY (Department_Id,Project_Id),
  FOREIGN KEY (Department_Id) REFERENCES Department(Department_Id),
  FOREIGN KEY (Project_Id) REFERENCES Project(Project_Id)
  );
  CREATE TABLE Education(
  Education_Id int primary key,
  Employee_Id int,
  Degree VARCHAR(30),
  Graduation_Year int(4),
  FOREIGN KEY (Employee_Id) REFERENCES Employee(Employee_Id)
  );
CREATE TABLE Restdays(
  Leave_Id int primary key,
  Employee_Id int,
  Leave_date DATE,
  FOREIGN KEY (Employee_Id) REFERENCES Employee(Employee_Id)
  );
   
  CREATE TABLE Attendance(
  Attendance_Id int primary key,
  Hours_Worked int
  );
CREATE TABLE Work_Location(
  Location_Id INT primary key,
  Location VARCHAR(25),
  Number_Of_Employees int,
  City VARCHAR(25),
  State VARCHAR(25)
  );
 CREATE TABLE Employee_Attendance(
  Employee_Id int,
  Attendance_Id int,
 PRIMARY KEY (Employee_Id,Attendance_Id),
  FOREIGN KEY (Employee_Id) REFERENCES Employee(Employee_Id),
  FOREIGN KEY (Attendance_Id) REFERENCES Attendance(Attendance_Id)
  );
 
 
INSERT INTO Employee VALUES (101,'Ojas','Phansekar','2024-04-07','New York City','New York'),
(102,'Vrushali','Patil','2018-06-21','Boston','Massachusetts'),
(103,'Pratik','Parija','2019-09-13','Chicago','Illinois'),
(104,'Chetan','Mistry','2011-04-12','Miami','Florida'),
(105,'Anugraha','Varkey','2017-08-16','Atlanta','Georgia'),
(106,'Rasagnya','Reddy','2018-06-25','San Mateo','California'),
(107,'Aishwarya','Boralkar','2010-12-15','San Francisco','California'),
(108,'Shantanu','Savant','2015-11-27','Seattle','Washington'),
(109,'Kalpita','Malvankar','2016-04-24','Boston','Massachusetts'),
(110,'Saylee','Bhagat','2014-05-19','San Francisco','California');

INSERT INTO Department VALUES (1,'Human Resources'),
(2,'Software Development'),
(3,'Data Analysis'),
(4,'Data Science'),
(5,'Business Intelligence'),
(6,'Data Engineering'),
(7,'Manufacturing'),
(8,'Quality Control');

INSERT INTO Project VALUES (21,'Dev','Whatever'),
(22,'Prod','do something'),
(23,'Test','focus'),
(24,'Nothing','do nothing'),
(25,'Research','focus on everything'),
(26,'Next Steps','find some way out');

INSERT INTO AccountDetails VALUES (40,'Santander','S12344',101),
(41,'Santander','S12345',102),
(42,'Santander','S12346',103),
(43,'Santander','S12347',104),
(44,'Chase','C12344',105),
(45,'Chase','C12345',106),
(46,'Chase','C12347',107),
(47,'Chase','C12334',108),
(48,'BOFA','C12378',109),
(49,'BOFA','C12390',110);

INSERT INTO Education VALUES (10,101,'MS',2017),
(11,102,'MS',2019),
 (12,104,'MS',2011),
(13,108,'MS',2015),
(14,109,'Bachelor',2013),
(15,107,'Bachelor',2008),
(16,106,'Bachelor',2007);

INSERT INTO Restdays VALUES (51,104,'2019-12-01'),
(52,108,'2019-08-19'),
(53,109,'2019-07-23'),
(54,107,'2019-03-19'),
(55,106,'2019-06-04'),
(56,104,'2019-08-05'),
(57,108,'2019-04-06'),
(58,109,'2019-12-07'),
(59,107,'2019-05-08'),
(60,106,'2019-01-09');

INSERT INTO Attendance VALUES (90,10),
(91,20),
(92,30),
(93,40),
(94,45),
(95,56),
(96,58);

INSERT INTO Work_Location VALUES (71,'North',4,'New York City','New York'),
(72,'North',4,'Boston','Massachusetts'),
(73,'North',4,'Chicago','Illinois'),
(74,'North',89,'Miami','Florida'),
(75,'South',90,'Atlanta','Georgia'),
(76,'South',100,'San Mateo','California'),
(77,'South',4,'San Francisco','California'),
(78,'South',2,'Seattle','Washington'),
(79,'South',25,'Alpharetta','Georgia'),
(80,'South',20,'Keene','New Hampshire'),
(81,'South',22,'Hampton','New Hampshire');


INSERT INTO Employee_Attendance VALUES (101,90),
(102,91),
(103,92),
(104,93),
(105,94),
(106,95),
(107,96),
(108,91),
(109,92),
(110,93);


INSERT INTO DepartmentProject VALUES (1,21),
(2,22),
(3,23),
(4,24),
(5,25),
(6,26),
(7,21),
(8,24);

INSERT INTO Salary VALUES (1,57600,30,200,1000,40),
(2,76800,40,300,1300,41),
(3,96000,50,400,1500,42),
(4,115200,60,500,1700,43),
(5,57600,30,200,1000,44),
(6,76800,40,300,1300,45),
(7,96000,50,400,1500,46),
(8,115200,60,500,1700,47),
(9,57600,30,200,1000,48),
(10,76800,40,300,1300,49);

select * from inactive_employees;

select * from tax_summary;

CALL GetEmployeeInfo(106);

CALL UpdateEmployeeSalary(3,102000);

Update Employee
	set State= 'Yonkers'
	where Employee_Id = 101;

Select * from Employee;

 Drop table Education;

select * from active_employees;

CALL UpdateSalo(5,79000);
select * from Salary;
CALL UpdateSalo(45,79000);
select * from Salary;


Update Employee
	set State= 'Massachusetts'
	where Employee_Id = 105;
    select * from Employee;
    